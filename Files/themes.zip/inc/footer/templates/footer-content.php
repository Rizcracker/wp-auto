<?php

// Include page footer top area
qi_template_part( 'footer', 'templates/parts/footer-top-area' );

// Include page footer bottom area
qi_template_part( 'footer', 'templates/parts/footer-bottom-area' );
