<?php

// Hook to include page title template
do_action( 'qi_action_page_title_template' );
